# 应用验证报告

## 固定案例

- 案例名称：燃气轮机异常振动诊断证据链。
- 输入问题：燃气轮机异常振动诊断流程。
- 演示集合：gas_turbine_ocr_demo_snapshot。
- 检索结果：集合 gas_turbine_ocr_demo_snapshot · 延迟 41.80 ms · 结果 5 · 后端 public-demo。
- 复核入口：`docs/challenge_cup/reproducibility/browser_demo_smoke_report.md`；`docs/challenge_cup/reproducibility/browser_demo_smoke_report.json`；`docs/challenge_cup/reproducibility/browser_screenshots/desktop_search_results.png`。

## 证据链

| 步骤 | record | 证据作用 | 人工判断 |
| --- | --- | --- | --- |
| 阈值判断 | `demo-maint-thresholds-076` | 给出排气温度散布度、轴承振动、滑油金属颗粒、压气机效率衰减等关键监测阈值。 | 作为异常振动和早期故障诊断线索，不能单独构成停机决策。 |
| 故障机理 | `demo-structure-fault-130` | 说明结构强度故障与不正常振动、停机风险之间的关系。 | 用于解释为什么振动异常需要结合机械损伤风险审查。 |
| 案例现象 | `demo-gt07-fault-021` | GT-07 升负荷至 75% 后，压气机出口温度从 430°C 升至 485°C，振动传感器 VIB-CMP-01 到 7.2 mm/s，并触发“压气机出口温度偏高”报警。 | 现象层证据，提示压气机出口温度偏高和振动异常需要联合分析。 |
| 检修结果 | `demo-gt07-repair-022` | 停机检查发现进气滤网压差偏高、滤网局部堵塞、压气机前三级叶片积灰；清理进气滤网、安排压气机叶片离线清洗并复位温度传感器后，温度回落至 438°C，振动值降至 3.1 mm/s。 | 形成“原因 -> 措施 -> 复机结果”的闭环证据。 |
| 处置建议 | `demo-gt07-manual-023` | 给出压气机出口温度偏高的常见原因：进气阻力增大、压气机叶片污染和温度传感器漂移；建议检查进气滤网、清洗压气机叶片、校验温度传感器。 | 可作为检修清单草案，必须由工程师结合现场工况人工确认。 |

## Scenario Coverage Matrix

| Scenario ID | Maintenance question | Evidence records | What it proves | Boundary |
| --- | --- | --- | --- | --- |
| `scenario-gt07-abnormal-vibration` | Can the package organize an abnormal-vibration diagnosis chain? | `demo-maint-thresholds-076`; `demo-structure-fault-130`; `demo-gt07-fault-021`; `demo-gt07-repair-022`; `demo-gt07-manual-023` | The fixed GT-07 flow links threshold screening, mechanism, symptom, repair result, and disposition advice. | Fixed local scenario only. |
| `scenario-maintenance-thresholds` | Can reviewers trace maintenance thresholds before case-level judgment? | `demo-maint-thresholds-076`; `evaluation/system_eval_questions.jsonl`; `docs/challenge_cup/03_实验评测报告.md` | The system can surface threshold evidence and bind it to the disclosed evaluation set. | Local course/project evidence only. |
| `scenario-compressor-temperature` | Can reviewers audit a compressor outlet temperature alarm path? | `demo-gt07-fault-021`; `demo-gt07-repair-022`; `demo-gt07-manual-023` | The same evidence chain connects alarm symptom, inlet-filter/compressor-blade findings, and manual disposition. | This is not production full-scenario validation. |

## 半量化收益

- 系统在演示快照中从 2,655 个向量片段、约 1,185,989 tokens 中返回 5 条证据结果，检索延迟为 41.80 ms。
- 人工原流程需要分别查找阈值、故障机理、案例现象、检修结果和处置建议；系统辅助后把这五类证据组织到同一页结果中。
- 对结项和挑战杯答辩的价值是：评委可以沿 record id 复核证据链，避免只听“系统能诊断”的口头承诺。

## 边界结论

本案例证明系统能辅助完成异常振动诊断的证据整理和来源追溯，但不证明它可以替代工程师做最终维修决策。GT-07 案例中的进气滤网、压气机叶片和温度传感器判断仍必须结合真实现场数据、设备规程和人工确认。
