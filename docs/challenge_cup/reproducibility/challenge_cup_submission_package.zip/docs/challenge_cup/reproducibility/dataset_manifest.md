# 数据集与证据清单

- 系统评测集：`evaluation/system_eval_questions.jsonl`，60 题。
- 评测覆盖画像：`docs/challenge_cup/reproducibility/evaluation_coverage_profile.json`。
- 普通 RAG 数据库说明：`docs/project_deliverables/03_普通RAG数据库_14本资料/数据库构建结果_人话版.md`。
- 知识图谱人工评审：`docs/project_deliverables/05_知识图谱POC_三元组和人工判断/人工判断小结.md`。
- Day3 baseline：`evaluation/reports/day3_retrieval_baseline_comparison_20260605_210540.md`。
- Day4 失败分析：`evaluation/reports/day4_failure_analysis_20260605_210642.md`。
- GraphRAG 同题子集：`evaluation/reports/challenge_cup_graphrag_same_question_report.md`。
- GraphRAG 同题 JSON：`evaluation/reports/challenge_cup_graphrag_same_question_report.json`。
- GraphRAG context-only demo：`evaluation/reports/challenge_cup_graphrag_context_demo.md`。
- GraphRAG context-only JSON：`evaluation/reports/challenge_cup_graphrag_context_demo.json`。
- GraphRAG answer benchmark：`evaluation/reports/challenge_cup_graphrag_answer_benchmark.md`。
- GraphRAG answer benchmark JSON：`evaluation/reports/challenge_cup_graphrag_answer_benchmark.json`。
- GraphRAG 补证整改计划：`evaluation/reports/challenge_cup_graphrag_gap_remediation_plan.md`。
- GraphRAG 补证整改 JSON：`evaluation/reports/challenge_cup_graphrag_gap_remediation_plan.json`。
- Day4 失败整改 before/after：`evaluation/reports/challenge_cup_failure_remediation_before_after.md`。
- Day4 失败整改 before/after JSON：`evaluation/reports/challenge_cup_failure_remediation_before_after.json`。
- GraphRAG manual evidence supplement：`docs/challenge_cup/reproducibility/graphrag_manual_evidence_supplement.csv`。
- 评审主张证据矩阵：`docs/challenge_cup/07_评审主张证据矩阵.md`。
- 特等奖评审自评表：`docs/challenge_cup/08_特等奖评审自评表.md`。
- 专家快速审阅索引：`docs/challenge_cup/09_专家快速审阅索引.md`。
- 评委现场速览卡：`docs/challenge_cup/13_评委现场速览卡.md`。
- 现场答辩操作 Runbook：`docs/challenge_cup/14_现场答辩操作Runbook.md`。
- 结项交付移交清单：`docs/challenge_cup/15_结项交付移交清单.md`。
- 现场问辩记录与整改台账：`docs/challenge_cup/16_现场问辩记录与整改台账.md`。
- 评审风险控制与应急预案：`docs/challenge_cup/17_评审风险控制与应急预案.md`。
- 特等奖打分模拟与整改清单：`docs/challenge_cup/18_特等奖打分模拟与整改清单.md`。
- 作品展墙报问辩与展台脚本：`docs/challenge_cup/19_作品展墙报问辩与展台脚本.md`。
- 成果转化与持续迭代路线图：`docs/challenge_cup/20_成果转化与持续迭代路线图.md`。
- 知识产权与开源合规说明：`docs/challenge_cup/21_知识产权与开源合规说明.md`。
- 同类方案对比与创新性证据卡：`docs/challenge_cup/22_同类方案对比与创新性证据卡.md`。
- 作品展 A0 展板源文件：`docs/challenge_cup/poster/challenge_cup_a0_poster.html`。
- 现场答辩总控台：`docs/challenge_cup/defense_console/index.html`。
- 评委质疑攻防矩阵：`docs/challenge_cup/reproducibility/judge_objection_response_matrix.md`。
- 答辩攻防与彩排卡：`docs/challenge_cup/10_答辩攻防与彩排卡.md`。
- 终审答辩 PPTX：`docs/challenge_cup/defense_deck/challenge_cup_defense_deck.pptx`。
- 终审答辩讲稿：`docs/challenge_cup/defense_deck/challenge_cup_defense_speaker_notes.md`。
- 答辩彩排计分卡：`docs/challenge_cup/reproducibility/defense_rehearsal_scorecard.md`。
- 答辩彩排计分 JSON：`docs/challenge_cup/reproducibility/defense_rehearsal_scorecard.json`。
- 答辩计时彩排结果归档包：`docs/challenge_cup/reproducibility/defense_rehearsal_result_packet.md`。
- 答辩计时彩排结果 JSON：`docs/challenge_cup/reproducibility/defense_rehearsal_result_packet.json`。
- 专家反馈外发包：`docs/challenge_cup/reproducibility/expert_feedback_request_packet.md`。
- 专家反馈外发 JSON：`docs/challenge_cup/reproducibility/expert_feedback_request_packet.json`。
- 应用场景与专家验证：`docs/challenge_cup/11_应用场景与专家验证.md`。
- 应用验证报告：`docs/challenge_cup/reproducibility/application_validation_report.md`。
- 专家反馈采集与整改闭环：`docs/challenge_cup/12_专家反馈采集与整改闭环.md`。
- 专家反馈采集表：`docs/challenge_cup/reproducibility/expert_feedback_form.md`。
- 现场演示烟测：`docs/challenge_cup/reproducibility/live_demo_smoke_report.md`。
- 真实浏览器演示烟测：`docs/challenge_cup/reproducibility/browser_demo_smoke_report.md`。
- 真实浏览器烟测 JSON：`docs/challenge_cup/reproducibility/browser_demo_smoke_report.json`。
- 结项 readiness gate：`docs/challenge_cup/reproducibility/readiness_gate_report.md`。
- 总目标完成门禁：`docs/challenge_cup/reproducibility/goal_completion_report.md`。
- 证据完整性哈希：`docs/challenge_cup/reproducibility/evidence_hashes.json`。
- 可提交归档包：`docs/challenge_cup/reproducibility/challenge_cup_submission_package.zip`。
- 可提交归档包哈希清单：`docs/challenge_cup/reproducibility/challenge_cup_submission_archive_manifest.json`。
- 浏览器验收截图：`docs/challenge_cup/reproducibility/browser_screenshots/`。
- 浏览器桌面总览截图：`docs/challenge_cup/reproducibility/browser_screenshots/desktop_overview.png`。
- 浏览器桌面检索截图：`docs/challenge_cup/reproducibility/browser_screenshots/desktop_search_results.png`。
- 浏览器 KG 产物截图：`docs/challenge_cup/reproducibility/browser_screenshots/desktop_kg_artifacts.png`。
- 浏览器移动端截图：`docs/challenge_cup/reproducibility/browser_screenshots/mobile_overview.png`。
- 课程最终交付包：`docs/project_deliverables/06_汇报材料_发群和组会/RAG课程汇报_最终交付包/README_先看这里.md`。

## 官方评审口径对齐

- 官方评审口径对齐表：`docs/challenge_cup/reproducibility/official_rubric_alignment.md`
- 官方评审口径 JSON：`docs/challenge_cup/reproducibility/official_rubric_alignment.json`

## Submission Package Offline Verification

- Offline verifier: `docs/challenge_cup/reproducibility/verify_submission_package.py`
- Final acceptance audit: `docs/challenge_cup/reproducibility/final_acceptance_audit.md`
- Final acceptance audit JSON: `docs/challenge_cup/reproducibility/final_acceptance_audit.json`
## 硬证据台账

- 硬证据台账：`docs/challenge_cup/reproducibility/hard_evidence_ledger.md`
- 硬证据 JSON：`docs/challenge_cup/reproducibility/hard_evidence_ledger.json`
- 硬证据归档入口：`docs/challenge_cup/reproducibility/hard_evidence/README.md`
- 真实专家反馈归档入口：`docs/challenge_cup/reproducibility/hard_evidence/expert_feedback/README.md`
- 真实计时彩排归档入口：`docs/challenge_cup/reproducibility/hard_evidence/timed_rehearsal/README.md`
- 专家反馈外发追踪台账：`docs/challenge_cup/reproducibility/expert_feedback_outreach_ledger.md`
- 专家反馈外发追踪 JSON：`docs/challenge_cup/reproducibility/expert_feedback_outreach_ledger.json`
- 专家反馈外发追踪入口：`docs/challenge_cup/reproducibility/expert_feedback_outreach/README.md`
- Timed rehearsal schedule ledger: `docs/challenge_cup/reproducibility/timed_rehearsal_schedule_ledger.md`
- Timed rehearsal schedule JSON: `docs/challenge_cup/reproducibility/timed_rehearsal_schedule_ledger.json`
- Timed rehearsal schedule intake: `docs/challenge_cup/reproducibility/timed_rehearsal_schedule/README.md`
- Hard evidence closure board: `docs/challenge_cup/reproducibility/hard_evidence_closure_board.md`
- Hard evidence closure JSON: `docs/challenge_cup/reproducibility/hard_evidence_closure_board.json`
- Hard evidence action pack: `docs/challenge_cup/reproducibility/hard_evidence_action_pack.md`
- Hard evidence action pack JSON: `docs/challenge_cup/reproducibility/hard_evidence_action_pack.json`
- External evidence execution kit: `docs/challenge_cup/reproducibility/external_evidence_execution_kit.md`
- External evidence execution kit JSON: `docs/challenge_cup/reproducibility/external_evidence_execution_kit.json`
- Expert review handoff: `docs/challenge_cup/reproducibility/external_evidence_execution_kit/expert_review_handoff.md`
- Timed rehearsal observer sheet: `docs/challenge_cup/reproducibility/external_evidence_execution_kit/timed_rehearsal_observer_sheet.md`
- Special prize readiness dashboard: `docs/challenge_cup/reproducibility/special_prize_readiness_dashboard.md`
- Special prize readiness dashboard JSON: `docs/challenge_cup/reproducibility/special_prize_readiness_dashboard.json`
- 终审提交总目录与签收页：`docs/challenge_cup/23_终审提交总目录与签收页.md`
